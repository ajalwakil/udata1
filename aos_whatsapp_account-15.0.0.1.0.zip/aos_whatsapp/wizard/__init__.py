# See LICENSE file for full copyright and licensing details.
from . import whatsapp_message
from . import check_partner_mobile
