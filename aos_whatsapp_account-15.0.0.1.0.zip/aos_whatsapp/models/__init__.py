# See LICENSE file for full copyright and licensing details.
from . import ir_whatsapp_server
from . import mail_message
from . import mail_thread
from . import res_partner